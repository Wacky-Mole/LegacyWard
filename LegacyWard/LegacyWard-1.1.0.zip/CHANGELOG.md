| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.7     | - Initial Thunderstore Release |
| 1.0.8     | - Updated Readme, inc version |
| 1.0.9     | - Ashlands Update - PieceManager|
| 1.1.0     | - Updates + Ward Is Love API |