| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.7     | - Initial Thunderstore Release |
| 1.0.9     | - Ashlands Update - PieceManager |