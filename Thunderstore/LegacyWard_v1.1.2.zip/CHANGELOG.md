| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.7     | - Initial Thunderstore Release |
| 1.0.9     | - Ashlands Update - PieceManager |
| 1.1.0     | - Updates + Ward Is Love API|
| 1.1.1     | - Released Under OdinPlus. A Big thank you to everyone over there! Removed KeyManager |
| 1.1.2     | - Fix for unintended non pickup of items.  