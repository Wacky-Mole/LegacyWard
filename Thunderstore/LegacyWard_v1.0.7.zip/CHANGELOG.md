| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.7     | - Initial Thunderstore Release |